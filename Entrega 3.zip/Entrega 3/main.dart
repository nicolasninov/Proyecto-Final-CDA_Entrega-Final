import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  String? selectedOption;
  final List<String> opciones = ['Tiempo de vuelo', 'Condición de batería resultante'];
  final List<String> labels = [
    'Pilot-in-Command',
    'Above Sea Level (Meters)​',
    'Drone Type',
    'Takeoff Bat %',
    'Takeoff mAh',
    'Takeoff Volts',
    'Max Altitude (Meters)',
    'Total Mileage (Kilometers)',
  ];
  String resultText = '';

  void updateResultText() {
    setState(() {
      if (selectedOption == 'Tiempo de vuelo') {
        resultText = '150 min';
      } else if (selectedOption == 'Condición de batería resultante') {
        resultText = 'Consumo alto';
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    double screenHeight = MediaQuery.of(context).size.height;
    double targetHeight = screenHeight * 0.75;

    return Scaffold(
      appBar: AppBar(
        title: Image.asset('Imagen_titulo.png'), 
      ),
      body: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            SizedBox(
              height: targetHeight,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Expanded(
                    child: Container(
                      child: Center(
                        child: DropdownButtonFormField<String>(
                          value: opciones.isNotEmpty ? opciones[0] : null,
                          items: opciones.map((String opcion) {
                            return DropdownMenuItem<String>(
                              value: opcion,
                              child: Text(opcion),
                            );
                          }).toList(),
                          onChanged: (String? newValue) {
                            setState(() {
                              selectedOption = newValue;
                            });
                          },
                          decoration: InputDecoration(
                            labelText: 'Tipo de pronóstico',
                            border: OutlineInputBorder(),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Expanded(
                    child: Container(
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: List.generate(
                            labels.length,
                            (index) => TextFormField(
                              decoration: InputDecoration(
                                labelText: labels[index],
                                border: OutlineInputBorder(),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Expanded(
                    child: Container(
                      child: Center(
                        child: Text(
                          resultText,
                          style: TextStyle(fontSize: 18),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: 20), // Espacio entre la fila de contenedores y el botón
            ElevatedButton(
              onPressed: () {
                updateResultText();
              },
              child: Text('Calcular'),
            ),
          ],
        ),
      ),
    );
  }
}